
Our code:
----------------------------------------------------------
The code we wrote for this application can be found in Trainer+/src/trainerPlus/ in the zip you downloaded.

# To Run Our Application

Prerequisites:
----------------------------------------------------------
1. JDK 8 installed on your machine. Download page: https://www.oracle.com/uk/java/technologies/javase/javase-jdk8-downloads.html
2. NetBeans 8.2 Download page: https://www.oracle.com/technetwork/java/javase/downloads/jdk-netbeans-jsp-3413139-esa.html
3. Glassfish server Download page: https://www.oracle.com/java/technologies/ogs-v3122-downloads.html


Setup NetBeans database:
----------------------------------------------------------
Follow this tutorial up to and including 'Connecting to the database' : https://netbeans.apache.org//kb/docs/ide/java-db.html
- When creating the database you can save it in the 'Group30_Prototype_CodeAndReadme' folder.

Use the following credentials for the database:
----------------------------------------------------------
	1. Database name: SEDB
	2. Username: username
	3. Password: password
----------------------------------------------------------

Setup Tables in database:
----------------------------------------------------------
Find files in the SEDB_Tables folder:
----------------------------------------------------------
	1. COURSES.grab
	2. EMPLOYEEINFO.grab
	3. SESSIONS.grab
----------------------------------------------------------
Follow the instructions below:
-----------------------------------------------------------
1. Connect to jdbc:derby://localhost:1527/SEDB [username on USERNAME] under your Databases node (Right click and press 'Connect')
2. Click on drop down for 'USERNAME'
3. Right click on 'Tables', select 'Recreate table'
4. Navigate to SEDB folder (from downloaded zip folder)
5. Select 'COURSES.grab' file, click 'Open'
6. Press 'OK' in the pop-up windown in NetBeans
7. Repeat step 3 to 6 for 'EMPLOYEEINFO.grab' and 'SESSIONS.grab'
-----------------------------------------------------------

Add derbyclient.jar to Project Libraries:
-----------------------------------------------------------
	1. Expand the project Trainer+ under the Projects tab in NetBeans
	2. Select the 'Libraries' dropdown and if derbyclient.jar is there then skip the next steps 2-6 (otherwise follow them)
	3. Right click on Libraries, select Add JAR/Folder...
	4. Find glassfish installation folder (usually under C://Program Files/glassfish-[version])
	5. In the installation folder, navigate to javadb/lib
	6. Select derbyclient.jar, click Open
-----------------------------------------------------------

When Running the Application
-----------------------------------------------------------------
Make sure the jdbc:derby://localhost:1527/SEDB is connected in the services tab/window in your NetBeans (in the dropdown 'Databases'), before you start running the project. If it is not connected then right click on the database connection jdbc:derby://localhost:1527/SEDB and press connect.
You can create accounts by registering through the registration screen, where the type of account you create is determined by the ID number you enter.
The first number of the ID will determine which account it is. So ID number starting with a number:

- 1 is for a Trainer account.
- 3 is for Assign Staff account.
- 4 is for Course Staff account.

For example:
- Trainer Account ID: 1XYZ
- Assign Staff Account ID: 3XYZ
- Course Staff Account ID: 4XYZ

-----------------------------------------------------------------

Sources used
-----------------------------------------------------------------
-	Combobox for dropdown menu for each session detail. Source: https://www.geeksforgeeks.org/javafx-combobox-with-examples/
-	Reading data from database in Java. Source: https://alvinalexander.com/java/java-mysql-select-query-example/
-	Inserting data into database in Java using SQL. Source: https://alvinalexander.com/blog/post/jdbc/create-use-preparedstatement/
-	Hashing SHA-256 in Java. Source: https://howtodoinjava.com/java/java-security/how-to-generate-secure-password-hash-md5-sha-pbkdf2-bcrypt-examples/
-	For CSS styling:
	- https://blog.e-zest.com/gradients-in-javafx-2/
	- https://docs.oracle.com/javafx/2/api/javafx/scene/doc-files/cssref.html
	- https://www.w3schools.com/howto/howto_css_round_buttons.asp
	- https://www.w3schools.com/howto/howto_css_round_buttons.asp
	- https://stackoverflow.com/questions/43557722/javafx-border-radius-background-color
	- https://stackoverflow.com/questions/38437700/javafx-combobox-css-style
	- https://www.w3schools.com/css/css3_borders.asp
	- https://docs.oracle.com/javase/8/javafx/get-started-tutorial/css.htm
	- Microsoft PowerPoint (for background image)

-----------------------------------------------------------------