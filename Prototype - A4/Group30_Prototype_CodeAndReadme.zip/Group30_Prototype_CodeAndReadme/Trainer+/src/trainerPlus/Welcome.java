
package trainerPlus;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author adil
 */
public class Welcome implements EventHandler<ActionEvent>{
    
    //Stage declaration
    private Stage window;
    
    
    //Label declarations
    private Label background;
    private Label usernameLabel;
    private Label passwordLabel;
    
    private Text FDMTitle;
    private Text errorMessage;

    //TextField declaration
    private TextField usernameEnter;

    //JPasswordField declaration variable
    private PasswordField passwordEnter;

    //Button declarations
    private Button login;
    private Button register;
    
    public Welcome(){
    
        window = new Stage();
        window.setTitle("Welcome to Trainer+");
        
        Rectangle2D screenSize = Screen.getPrimary().getVisualBounds();//gets dimensions of your computer screen
        
        BorderPane border = new BorderPane();
        
        GridPane layout = new GridPane();
        layout.setAlignment(Pos.CENTER);
        layout.setHgap(10);
        layout.setVgap(10);
        layout.setPadding(new Insets(25, 25, 25, 25));   
        
        //Title
        //BorderPane titleLayout = new BorderPane();
        FDMTitle = new Text();
        FDMTitle.setText("   FDM\nTrainer+");
        FDMTitle.setId("title");
        layout.add(FDMTitle, 1, 0);
        //titleLayout.setTop(FDMTitle);
        
        //Username 
        usernameLabel = new Label("Username:");
        layout.add(usernameLabel, 0, 1);

        usernameEnter = new TextField();
        layout.add(usernameEnter, 1, 1);
        // String username = usernameEnter.getText();
        // System.out.println(username);

        //Password
        passwordLabel = new Label("Password:");
        layout.add(passwordLabel, 0, 2);

        passwordEnter = new PasswordField();
        layout.add(passwordEnter, 1, 2);


        //error message properties
        errorMessage = new Text();
        errorMessage.setId("error-Message");
        layout.add(errorMessage, 1, 6);


        //Buttons' properties
        login = new Button("Log In");
        layout.add(login, 1, 3);
        
        register = new Button("Register");
        layout.add(register, 0, 3);
        //register.setBounds(700, 430, 110, 20);
        
        login.setOnAction(this);
        register.setOnAction(this);
       
        border.setCenter(layout);
        
        Scene scene = new Scene(border, screenSize.getWidth(), screenSize.getHeight());//sets scene to screen size
        
        scene.getStylesheets().add(Welcome.class.getResource("WelcomeScreens.css").toExternalForm());//links this class to css file
        
        window.setScene(scene);
        window.show();
    }
    
    
    @Override
    public void handle(ActionEvent event) {
        
        
        if(event.getSource() == login){
            String usernameEntered = usernameEnter.getText();
            String passwordEntered = passwordEnter.getText();
            //gets hashed password to compare with database hashed passwords
            passwordEntered = Main.getHashedPassword(passwordEntered);
  
            try {
                //connect to database
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");

                String query = "SELECT * FROM USERNAME.EMPLOYEEINFO";

                //create java statement
                Statement statement = con.createStatement();

                ResultSet results = statement.executeQuery(query);

                boolean found = false;
                
                //iterate through database table records
                while(results.next()){
                    String name = results.getString("Usernames");
                    String pass = results.getString("Passwords");
                    String id = results.getString("ID");
                    
                    //check if username and passwords (hashed) are correct in database
                    if(usernameEntered.equals(name) && passwordEntered.equals(pass)){
                        found = true;
                        switch (id.charAt(0)) {
                            //for trainers
                            case '1':
                                //we know it is a Trainer object so need to get 
                                //it to pass the correct Trainer object to TrainerScreen object on login
                                
                                for (int i = 0; i < Trainer.getListOfTrainers().size(); i++) {
                                    if(Trainer.getListOfTrainers().get(i).getID().equals(id)){
                                        
                                        new TrainerScreen(Trainer.getTrainer(id));
                                        break;
                                    }
                                }
                                
                                
                                break;
                            case '2':
                                //for trainees

                                break;
                            case '3':
                                //for assign staff users
                                
                                for (AssignStaff assignUser : AssignStaff.getListOfAssignUsers()) {
                                    if(assignUser.getID().equals(id)){
                          
                                        new AssignStaffScreen(assignUser);
                                        break;
                                    }
                                }
               
                                break;
                            case '4':
                                for (CourseStaff courseUser : CourseStaff.getListOfCourseStaff()) {
                                    if(courseUser.getID().equals(id)){
                                        //grant login of course staff user
                                        new CourseStaffScreen(courseUser);  
                                        break;
                                    }
                                }
                                break;
                            default:
                                System.out.println("ID found is not assigned to any user of this system");
                                break;
                        }  
                    }
                    
                    if(found){
                        break;//no need to check rest of records if user found
                    }
                }
                
                statement.close();//close connection
                if(found){
                    //close login screen when login was successful
                    window.close();
                    
                }
                else{//error message when data entered doesn't match database records 
                    errorMessage.setText("Invalid username or password");
                    //System.out.println("invalid login");
                }
 
            } catch (Exception e) {
                System.out.println("error: "+ e);
            }
            
        }
        else if(event.getSource() == register){
            new Register();
            window.close();
           
        }
    }

   
    
}
