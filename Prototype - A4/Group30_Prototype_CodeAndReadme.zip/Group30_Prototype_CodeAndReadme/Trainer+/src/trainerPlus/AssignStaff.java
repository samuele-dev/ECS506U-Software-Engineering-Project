
package trainerPlus;

import java.util.ArrayList;

/**
 *
 * @author adil
 */
public class AssignStaff {
    
    private String username;
    private String ID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    
    private static ArrayList<AssignStaff> assignUsers;
    
    public AssignStaff(String uName, String identifier, String fName, String lName, String mail, String phone){
        username = uName;
        ID = identifier;
        firstName = fName;
        lastName = lName;
        email = mail;
        phoneNumber = phone;
        
    }
    
    
    //function to return the ID of current object
    public String getID(){
        return ID;
    }
    
    //function to return the username of current object
    public String getUsername(){
        return username;
    }
    
    //This function returns the first name of this user
    public String getFirstName(){
        return firstName;
    }
    
    //This function returns the last name of this user
    public String getLastName(){
        return lastName;
    }
    
    //This function returns the email for this user
    public String getEmail(){
        return email;
    }
    
    //This function returns the phone number for this user
    public String getPhoneNumber(){
        return phoneNumber;
    }
    
    //add session method for trainer
    public void addSession(Trainer trainer, Session session){
        trainer.addSession(session);
    }
    
    
    /*
    Static functions below
    */
    
    //create a new arraylist of type AssignStaff
    public static void createList(){
        assignUsers = new ArrayList<AssignStaff>();
    }
    
    //add an assignstaff object to the list of AssignStaff objects
    public static void addAssignUserToList(AssignStaff user){
        assignUsers.add(user);
    }
    
    //return list of AssignStaff objects
    public static ArrayList<AssignStaff> getListOfAssignUsers(){
        return assignUsers;
    }
    
}
