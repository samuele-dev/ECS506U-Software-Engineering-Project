
package trainerPlus;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author adil
 */
public class Schedule {
    
   
    private ArrayList<Session> sessions;//contains all sessions
   
    private String userID;
    
    
    public Schedule(String uID){
        userID = uID;
        sessions = new ArrayList<Session>();//this array will contain all sessions for all weeks

    }
    
    
    
    //Object methods below:
    
    public void getDatabaseData(){
        //get all sessions for user from database to put in schedule object and
        //all of this will be part of the object it was created in
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");

            String query = "SELECT * FROM USERNAME.SESSIONS";

            //create java statement
            Statement statement = con.createStatement();

            ResultSet record = statement.executeQuery(query);
            
            //iterate through every record
            while(record.next()){
                String userIdentifier = record.getString("USERID");
                if(userID.equals(userIdentifier)){
                    //found a session record for this specific user
                    String name = record.getString("NAME");
                    String startTime = record.getString("STARTTIME");
                    String endTime = record.getString("ENDTIME");
                    String week = record.getString("WEEK");
                    String day = record.getString("DAY");
                    String location = record.getString("LOCATION");
                    
                    //create new session object based on database data
                    Session session = new Session(name, startTime, endTime, week, day, location);
                    sessions.add(session);//add this to sessions list
                
                }
                
            
            }
            
            statement.close();  
            
        } catch (Exception e) {
            System.out.println("Error getting sessions details");
            
        }
        
    }
    
    public void addToDatabase(Session session){
        try{
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");

            String insert = "INSERT INTO USERNAME.SESSIONS VALUES (?, ?, ?, ?, ?, ?, ?)";

            //create java prepared statement so we can update data in table using data given from user
            PreparedStatement statement = con.prepareStatement(insert);

            //add registration details to database
            statement.setString(1, session.getName());
            statement.setString(2, session.getStartTime());
            statement.setString(3, session.getEndTime());
            statement.setString(4, session.getWeek());
            statement.setString(5, session.getDay());
            statement.setString(6, session.getLocation());
            statement.setString(7, userID);

            statement.executeUpdate();
            statement.close();
            
            
        }catch (Exception e) {
            System.out.println("Could not add session to database");
            System.out.println("error: "+ e);
        }
    
    }
    
    //This method will get the schedule (all the sessions) for a specific week
    public ArrayList<Session> getSchedule(String week){
        ArrayList<Session> sessionsForThisWeek = new ArrayList<Session>();
        
        for (Session session : getSessionsList()) {
            if(session.getWeek().equals(week)){
                sessionsForThisWeek.add(session);
                //adds to session object list only sessions for this specified
                //week and the it returns to user object that called this.
            }
        }
        
        return sessionsForThisWeek;
    }
    
    //This method returns the whole sessions list (with all weeks)
    public ArrayList<Session> getSessionsList(){
        return sessions;
    }
    
    
    
    
}
