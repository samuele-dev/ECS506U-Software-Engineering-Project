
package trainerPlus;

import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

/**
 *
 * @author adil
 */
public class Calendar {
    
    private static int numberOfMondaySessions = 0;
    private static int numberOfTuesdaySessions = 0;
    private static int numberOfWednesdaySessions = 0;
    private static int numberOfThursdaySessions = 0;
    private static int numberOfFridaySessions = 0;
    
    public Calendar(){
    
    }
    
    public static int getNumberOfMondaySessions(){
        return numberOfMondaySessions;
    }
    
    public static int getNumberOfTuesdaySessions(){
        return numberOfTuesdaySessions;
    }
    
    public static int getNumberOfWednesdaySessions(){
        return numberOfWednesdaySessions;
    }
    
    public static int getNumberOfThursdaySessions(){
        return numberOfThursdaySessions;
    }
    
    public static int getNumberOfFridaySessions(){
        return numberOfFridaySessions;
    }
    
    
    public static GridPane getCalendar(Trainer trainer, int weekNo, String fromUser){
        numberOfMondaySessions = 0;
        numberOfTuesdaySessions = 0;
        numberOfWednesdaySessions = 0;
        numberOfThursdaySessions = 0;
        numberOfFridaySessions = 0;
        ArrayList<Session> sessions; 
        //Create layout within main content
        GridPane calendar = new GridPane();
        calendar.setId("schedule");//id for css styling
        if(fromUser.equals("trainer")){
            //for trainer screen schedule
            calendar.setVgap(50);//set vertical spacing between grid cells
            calendar.setHgap(25);//set horizontal spacing between grid cells
        }
        else{
            //for when assign staff views trainer schedule
            calendar.setVgap(20);//set vertical spacing between grid cells
            calendar.setHgap(15);//set horizontal spacing between grid cells
        }
        
        calendar.setPadding(new Insets(20, 20, 20, 20));//set insets
        

        //Day labels
        Label monday = new Label("Monday");
        monday.setId("time-day-labels");//for css styling
        Label tuesday = new Label("Tuesday");
        tuesday.setId("time-day-labels");
        Label wednesday = new Label("Wednesday");
        wednesday.setId("time-day-labels");
        Label thursday = new Label("Thursday");
        thursday.setId("time-day-labels");
        Label friday = new Label("Friday");
        friday.setId("time-day-labels");
        
        calendar.add(monday, 1, 2);
        calendar.add(tuesday, 2, 2);
        calendar.add(wednesday, 3, 2);
        calendar.add(thursday, 4, 2);
        calendar.add(friday, 5, 2);
        
        
        //Time labels
        Label nineToTen = new Label("9-10");
        nineToTen.setId("time-day-labels");//for css styling
        Label tenToEleven = new Label("10-11");
        tenToEleven.setId("time-day-labels");//for css styling
        Label elevenToTwelwe = new Label("11-12");
        elevenToTwelwe.setId("time-day-labels");//for css styling
        Label twelweToOne = new Label("12-13");
        twelweToOne.setId("time-day-labels");//for css styling
        Label oneToTwo = new Label("13-14");
        oneToTwo.setId("time-day-labels");//for css styling
        Label twoToThree = new Label("14-15");
        twoToThree.setId("time-day-labels");//for css styling
        
        calendar.add(nineToTen, 0, 3);
        calendar.add(tenToEleven, 0, 4);
        calendar.add(elevenToTwelwe, 0, 5);
        calendar.add(twelweToOne, 0, 6);
        calendar.add(oneToTwo, 0, 7);
        calendar.add(twoToThree, 0, 8);
         
        //get string of int week number
        String week = String.valueOf(weekNo);
        
        //display week number on top of calendar
        Text weekNoTitle = new Text();
        weekNoTitle.setId("week-title");
        weekNoTitle.setText("Week: "+week);
        calendar.add(weekNoTitle, 0, 0);
        
        //get the sessions for the current week for this trainer
        sessions = trainer.getSchedule(week);
        
        //get sessions for each day in the week
        calendar = getSpecificDaySessions(sessions, "Monday", calendar);
        calendar = getSpecificDaySessions(sessions, "Tuesday", calendar);
        calendar = getSpecificDaySessions(sessions, "Wednesday", calendar);
        calendar = getSpecificDaySessions(sessions, "Thursday", calendar);
        calendar = getSpecificDaySessions(sessions, "Friday", calendar);
           
        
        return calendar;
    }
    
    
    //This function will fill out the schedule of sessions for a specific day in the week
    public static GridPane getSpecificDaySessions(ArrayList<Session> sessions, String day, GridPane dayContent){
        
        //get the column position of the current day so content matches day
        int dayColumnPos = getDayColumnPosition(day);
        
        //positions for time labels to content matches
        int posNineToTen = 3;
        int posTenToEleven = 4;
        int posElevenToTwelwe = 5;
        int posTwelweToOne = 6;
        int posOneToTwo = 7;
        int posTwoToThree = 8;
        
        
        
        //eliminate duplicate sessions
        checkDuplicateSessions(sessions, day);
        
        //iterate through every session (only check for this day)
        for (Session session : sessions) {
            if(session.getDay().equals(day)){
                //this is for keeping count of how many sessions in each day in a week
                if(day.equals("Monday")){
                    numberOfMondaySessions++;
                }
                else if(day.equals("Tuesday")){
                    numberOfTuesdaySessions++;
                }
                else if(day.equals("Wednesday")){
                    numberOfWednesdaySessions++;
                }
                else if(day.equals("Thursday")){
                    numberOfThursdaySessions++;
                }
                else if(day.equals("Friday")){
                    numberOfFridaySessions++;
                }
                
                //the following if statements are to determine where in the gridpane
                //layout to put the session details for this specific session (in terms of time labels)
                
                //we made the assumption each session is 1 hour minimum and can
                //be up to 2 hours maximum
                if(session.getStartTime().equals("9")){
                    //get name and location for every session to display
                    Label sessionDetails = new Label();
                    sessionDetails.setId("session-details");
                    sessionDetails.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                    //one hour session
                    dayContent.add(sessionDetails, dayColumnPos, posNineToTen);
                    
                    if(session.getEndTime().equals("11")){
                        //two hour session
                        Label session2Details = new Label();
                        session2Details.setId("session-details");
                        session2Details.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                        
                        System.out.println("added to monday 9-11 content");
                        dayContent.add(session2Details, dayColumnPos, posTenToEleven);
                    }
                    
                }
                else if(session.getStartTime().equals("10")){
                    Label sessionDetails = new Label();
                    sessionDetails.setId("session-details");
                    sessionDetails.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                    dayContent.add(sessionDetails, dayColumnPos, posTenToEleven);
                    
                    if(session.getEndTime().equals("12")){
                        Label session2Details = new Label();
                        session2Details.setId("session-details");
                        session2Details.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                        dayContent.add(session2Details, dayColumnPos, posElevenToTwelwe);
                    }
                    
                }
                else if(session.getStartTime().equals("11")){
                    Label sessionDetails = new Label();
                    sessionDetails.setId("session-details");
                    sessionDetails.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                    dayContent.add(sessionDetails, dayColumnPos, posElevenToTwelwe);
                    
                    if(session.getEndTime().equals("13")){
                        Label session2Details = new Label();
                        session2Details.setId("session-details");
                        session2Details.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                        dayContent.add(session2Details, dayColumnPos, posTwelweToOne);
                    }
                }
                else if(session.getStartTime().equals("12")){
                    Label sessionDetails = new Label();
                    sessionDetails.setId("session-details");
                    sessionDetails.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                    dayContent.add(sessionDetails, dayColumnPos, posTwelweToOne);
                    
                    if(session.getEndTime().equals("14")){
                        Label session2Details = new Label();
                        session2Details.setId("session-details");
                        session2Details.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                        dayContent.add(session2Details, dayColumnPos, posOneToTwo);
                    }
                }
                else if(session.getStartTime().equals("13")){
                    Label sessionDetails = new Label();
                    sessionDetails.setId("session-details");
                    sessionDetails.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                    dayContent.add(sessionDetails, dayColumnPos, posOneToTwo);
                    
                    if(session.getEndTime().equals("15")){
                        Label session2Details = new Label();
                        session2Details.setId("session-details");
                        session2Details.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                        dayContent.add(session2Details, dayColumnPos, posTwoToThree);
                    }
                }
                else if(session.getStartTime().equals("14")){
                    Label sessionDetails = new Label();
                    sessionDetails.setId("session-details");
                    sessionDetails.setText("Name: "+session.getName()+ "\nLocation: "+session.getLocation());
                    dayContent.add(sessionDetails, dayColumnPos, posTwoToThree);
                    
                }
                else{
                    System.out.println("Session not within day working times");
                }
               
            }
        }

        return dayContent;
    }
    
    //This method will get the column position in the gridpane layout for a specific day
    public static int getDayColumnPosition(String day){
        int dayColumnPos;
        
        switch (day){
            case "Monday":
                dayColumnPos = 1;
                break;
            case "Tuesday":
                dayColumnPos = 2;
                break;
            case "Wednesday":
                dayColumnPos = 3;
                break;
            case "Thursday":
                dayColumnPos = 4;
                break;
            case "Friday":
                dayColumnPos = 5;
                break;
            default:
                dayColumnPos = 0;
                System.out.println("Error in finding column position");
                break;
                
        }
        
        return dayColumnPos;
    }
    
    //This method will avoid having multiple of same sessions on the same day
    public static void checkDuplicateSessions(ArrayList<Session> sessions, String day){
        //we made the assumption that you cannot have the same session twice or more on the same day
        
        //no need to do check if one session only in array
        if(sessions.size() == 1){
            return;
        }
        
        //check if session already retrieved for that same day so there are no multiple of
        //same sessions objects in array
        for (int i = 0; i < sessions.size(); i++) {
            //System.out.println("Pos i in session: "+i+" and session is: "+sessions.get(i).getName());
            for (int j = i+1; j < sessions.size(); j++) {
                //System.out.println("check one: "+sessions.get(i).getName());
                //System.out.println("check against: "+sessions.get(j).getName());
                if(sessions.get(j).getDay().equals(day) && sessions.get(i).getDay().equals(day)){
                    if(sessions.get(j).getName().equals(sessions.get(i).getName())){
                        //remove duplicate object
                        //System.out.println("Removed duplicate session: "+sessions.get(j).getName());
                        sessions.remove(sessions.get(j));   
                    }
                    
                }
                
            }
            
            //check last session in array and if array is greater than 2 elements still
            if(sessions.size() >= 2){
                //this is because of the for loop above; if theres 2 alike then one is 
                //removed (you end up with an array of one element) 
                //so now execute what's below cause it checks 2 elements
                if(i == sessions.size()-1){
                    if(sessions.get(i-1).getDay().equals(day) && sessions.get(i).getDay().equals(day)){
                        if(sessions.get(i-1).getName().equals(sessions.get(i).getName())){
                            sessions.remove(sessions.get(i));   
                        }
                    }
                }
            }
        }
        
    }
    
}
