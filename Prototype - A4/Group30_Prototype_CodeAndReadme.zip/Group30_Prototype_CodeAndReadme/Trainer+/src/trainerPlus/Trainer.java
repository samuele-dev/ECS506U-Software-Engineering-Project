
package trainerPlus;

import java.util.ArrayList;

/**
 *
 * @author adil
 */
public class Trainer {
    
    
    private static ArrayList<Trainer> trainers;
    
    private String username;
    private String ID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
   
    
    private ArrayList<Session> sessions;//contains all sessions
    private Schedule schedule; //object to separate sessions into weeks
   
    
    //constructor
    public Trainer(String uName, String identifier, String fName, String lName, String mail, String phone){
        username = uName;
        ID = identifier;
        firstName = fName;
        lastName = lName;
        email = mail;
        phoneNumber = phone;
       
        
        sessions = new ArrayList<Session>();
        schedule = new Schedule(ID);//create schedule for this user
        
    
    }
    
    
    /*
    These non static functions are to be used for each Trainer object
    */
    
    //function to return the ID of current object
    public String getID(){
        return ID;
    }
    
    //function to return the username of current object
    public String getUsername(){
        return username;
    }
    
    //This function returns the first name of this user
    public String getFirstName(){
        return firstName;
    }
    
    //This function returns the last name of this user
    public String getLastName(){
        return lastName;
    }
    
    //This function returns the email for this user
    public String getEmail(){
        return email;
    }
    
    //This function returns the phone number for this user
    public String getPhoneNumber(){
        return phoneNumber;
    }
    
    public ArrayList<Session> getSchedule(String week){
        schedule.getDatabaseData();
        ArrayList<Session> sessionsForThisWeek = schedule.getSchedule(week);
        return sessionsForThisWeek;
    }
    
    public void addSession(Session session){
        schedule = new Schedule(ID);
        schedule.addToDatabase(session);
        schedule.getDatabaseData();
    }
    
    
    
    /*
    Static functions below are to be used for all objects of this class
    i.e. Methods that belong to the class and not every object
    */
    
    //function to return corresponding trainer based on their ID 
    public static Trainer getTrainer(String ID){
        Trainer trainer = null;//it will stay null if trainer is not found
        
        //iterate through every object trainer
        for (Trainer t : Trainer.getListOfTrainers()){
            if(t.getID().equals(ID)){
                trainer = t;
                //correct trainer found
                break;
            }
        }
        
        return trainer;
    }
    
    //create a new arraylist of type Trainer
    public static void createList(){
        trainers = new ArrayList<Trainer>();
    }
    
    //add a trainer object to the list of Trainer objects
    public static void addTrainerToList(Trainer trainer){
        trainers.add(trainer);
    }
    
    //return list of Trainer objects
    public static ArrayList<Trainer> getListOfTrainers(){
        return trainers;
    }
    
    
}
