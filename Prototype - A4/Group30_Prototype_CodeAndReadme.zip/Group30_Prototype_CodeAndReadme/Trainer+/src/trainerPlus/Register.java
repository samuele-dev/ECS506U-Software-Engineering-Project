
package trainerPlus;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author adil
 */
public class Register implements EventHandler<ActionEvent> {
    
    
    private Stage window;
    
    //Label declarations
    private Label firstnameLabel;
    private Label lastnameLabel;
    private Label usernameLabel;
    private Label passwordLabel;
    private Label confirmPasswordLabel;
    private Label ID;
    private Label emailLabel;
    private Label phoneLabel;

    private Text errorMessage;

    //TextField declaration
    private TextField firstnameInput;
    private TextField lastnameInput;
    private TextField usernameInput;
    private TextField IDInput;
    private TextField emailInput;
    private TextField phoneInput;
    

    //PasswordField declaration variable
    private PasswordField passwordInput;
    private PasswordField confirmPasswordInput;

    //Button declarations
    private Button register;
    private Button goBack;
    

    public Register(){
        
        window = new Stage();
        window.setTitle("Registration Form");
        
        Rectangle2D screenSize = Screen.getPrimary().getVisualBounds();//gets dimensions of your computer screen
        
        GridPane layout = new GridPane();
        layout.setAlignment(Pos.CENTER);
        layout.setHgap(10);
        layout.setVgap(10);
        layout.setPadding(new Insets(25, 25, 25, 25));    
        
        //FDM ID 
        ID = new Label("FDM ID:");
        layout.add(ID, 0, 1);

        IDInput = new TextField();
        layout.add(IDInput, 1, 1);
        
        //First name
        firstnameLabel = new Label("First Name:");
        layout.add(firstnameLabel, 0, 2);

        firstnameInput = new TextField();
        layout.add(firstnameInput, 1, 2);
        
        //Last name 
        lastnameLabel = new Label("Last Name:");
        layout.add(lastnameLabel, 0, 3);

        lastnameInput = new TextField();
        layout.add(lastnameInput, 1, 3);
        
        //Email
        emailLabel = new Label("Email:");
        layout.add(emailLabel, 0, 4);

        emailInput = new TextField();
        layout.add(emailInput, 1, 4);
        
        //Phone number
        phoneLabel = new Label("Phone No.:");
        layout.add(phoneLabel, 0, 5);

        phoneInput = new TextField();
        layout.add(phoneInput, 1, 5);
        
        //Username
        usernameLabel = new Label("Username:");
        layout.add(usernameLabel, 0, 6);

        usernameInput = new TextField();
        layout.add(usernameInput, 1, 6);
        
        //Password 
        passwordLabel = new Label("Password:");
        layout.add(passwordLabel, 0, 7);

        passwordInput = new PasswordField();
        layout.add(passwordInput, 1, 7);
        
        //Confirm password 
        confirmPasswordLabel = new Label("Confirm Password:");
        layout.add(confirmPasswordLabel, 0, 8);

        confirmPasswordInput = new PasswordField();
        layout.add(confirmPasswordInput, 1, 8);
        

        //error message properties
        errorMessage = new Text();
        errorMessage.setId("error-Message");
        layout.add(errorMessage, 1, 9);


        //Buttons' properties
        goBack = new Button("Go Back");
        layout.add(goBack, 0, 10);
        
        register = new Button("Register");
        layout.add(register, 1, 10);
        //register.setBounds(700, 430, 110, 20);
        
        goBack.setOnAction(this);
        register.setOnAction(this);
        
        Scene scene = new Scene(layout, screenSize.getWidth(), screenSize.getHeight());//sets scene to screen size
        
        scene.getStylesheets().add(Welcome.class.getResource("WelcomeScreens.css").toExternalForm());//links this scene to css file
        
        window.setScene(scene);
        window.show();
    }
    
 
    @Override
    public void handle(ActionEvent event) {
        if(event.getSource() == goBack){
            new Welcome();
            window.close();
        }
        else if(event.getSource() == register){
            //errorMessage.setText("Invalid username or password");
            String username = usernameInput.getText();
            String password = passwordInput.getText();
            String confirmPass = confirmPasswordInput.getText();
            String ID = IDInput.getText();
            String firstName = firstnameInput.getText();
            String lastName = lastnameInput.getText();
            String email = emailInput.getText();
            String phoneNo = phoneInput.getText();
            
            /*check here if two passwords match and no fields are empty*/
            //Check if any fields are empty
            if(ID.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(firstName.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(lastName.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(email.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(phoneNo.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(username.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(password.isEmpty()){
                errorMessage.setText("Please fill out all fields");
            }
            else if(confirmPass.isEmpty()){ 
                errorMessage.setText("Please fill out all fields");
            }
            else if(!password.equals(confirmPass)){
                //check if password and confirm password matches
                errorMessage.setText("Passwords do not match");
            }
            else{
                //all fields filled out correctly then add to database and create object
                //hash password and then add this to database
                password = Main.getHashedPassword(password);
                
                /*Insert into database data.
                Source: https://alvinalexander.com/blog/post/jdbc/create-use-preparedstatement/
                */
                try {
                    //connect to database
                    Class.forName("org.apache.derby.jdbc.ClientDriver");
                    Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");

                    String insert = "INSERT INTO USERNAME.EMPLOYEEINFO VALUES (?, ?, ?, ?, ?, ?, ?)";

                    //create java prepared statement so we can update data in table using data given from user
                    PreparedStatement statement = con.prepareStatement(insert);

                    //add registration details to database
                    statement.setString(1, username);
                    statement.setString(2, password);
                    statement.setString(3, ID);
                    statement.setString(4, firstName);
                    statement.setString(5, lastName);
                    statement.setString(6, email);
                    statement.setString(7, phoneNo);

                    statement.executeUpdate();
                    statement.close();
                    //System.out.println("successful adding to database");

                    //if successful in adding to database then create correct user object depending on ID
                    switch (ID.charAt(0)) {
                        case '1':
                            //create new Trainer object and add to list of trainers
                            Trainer trainer = new Trainer(username, ID, firstName, lastName, email, phoneNo);
                            Trainer.addTrainerToList(trainer);
                            break;
                        case '2':

                            break;
                        case '3':
                            //create new AssignStaff object and add to list of assign staff users
                            AssignStaff assignStaff = new AssignStaff(username, ID, firstName, lastName, email, phoneNo);
                            AssignStaff.addAssignUserToList(assignStaff);
                            break;
                        case '4':
                            //create new CourseStaff object and add to list of assign staff users
                            CourseStaff courseUser = new CourseStaff(username, ID, firstName, lastName, email, phoneNo);
                            CourseStaff.addCourseStaffToList(courseUser);
                            break;
                        default:
                            System.out.println("ID found is not assigned to any user of this system");
                            System.out.println("Invalid ID entered");
                            break;

                    }
            
                    new Welcome();
                    window.close();

                } catch (Exception e) {
                    errorMessage.setText("ID or username already exists");
                    //System.out.println("ID or username already exists, not unique");
                    //System.out.println("error: "+ e);
                }
            }
            
        
        }
    }
        
    
}
