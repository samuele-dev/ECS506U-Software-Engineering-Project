
package trainerPlus;

import java.util.ArrayList;

/**
 *
 * @author tony
 */
public class Course {
    private static ArrayList<Course> courses;

    private String courseName;
    private String courseID;
    private Boolean status;
    
    public Course(String cName, String cID, Boolean sts) {
        courseName = cName;
        courseID = cID;
        status = true;
    }
    
    public String getCourseID(){
        return courseID;
    }
    
    public Boolean getStatus(){
        return status;
    }
    
    public String getCourseName(){
        return courseName;
    }
    
    public void setStatus(Boolean boo){
        status = boo;
    }
    
    
    public static void createCourseList(){
        courses = new ArrayList<Course>();
    }
    
    public static void addToCourseList(Course c){
        courses.add(c);
    }
    
    public static ArrayList<Course> getCourseList(){
        return courses;
    }
    
    
}
