
package trainerPlus;


import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author adil
 */
public class CourseStaffScreen implements EventHandler<ActionEvent>{
    private CourseStaff currentUser;
    private String tID;
    
    private Stage window;
    private Rectangle2D screenSize;
    
    private Button[] menuOptions;
    
    private Text confirmMessage;
    
     public CourseStaffScreen(CourseStaff current){
        currentUser = current;
        window = new Stage();
        window.setTitle("FDM Trainer+");
        
        screenSize = Screen.getPrimary().getVisualBounds();//gets dimensions of your computer screen
        
        BorderPane screen = new BorderPane();
        screen.setLeft(getMenuScreen());
        screen.setCenter(getMainScreen());
        
        Scene scene = new Scene(screen, screenSize.getWidth(), screenSize.getHeight());
        
        addStyleSheet(scene);
        
        
        window.setScene(scene);
        window.show();
}
    @Override
    public void handle(ActionEvent event) {
        if(event.getSource() == menuOptions[0]){
            //Create course button pressed
            
            BorderPane newScreen = new BorderPane();
            AnchorPane main = getMainScreen();
           
            GridPane content = getCreateCourseScreen();
            main.getChildren().add(content);
            
           
            newScreen.setLeft(getMenuScreen());
            newScreen.setCenter(main);
            Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
            addStyleSheet(scene2);
            window.setScene(scene2);
            
            
            
        }
        else if (event.getSource() == menuOptions[1]){
            //Deactivate course button clicked
            
        
        }
        
        else if (event.getSource() == menuOptions[2]){
            //Update course button clicked
         
        
        }
        else if (event.getSource() == menuOptions[3]){
            //log out pressed
            new Welcome();
            window.close();
        }
        
        
    }
    
    //Function to get the default screen so it is easier to switch between scenes
    public AnchorPane getMainScreen(){
        //Create main screen container
        AnchorPane mainContainer = new AnchorPane();
        mainContainer.setId("main-container");//id for css styling
        
        
        return mainContainer;
    }
    
    //gets menu 
    public AnchorPane getMenuScreen(){
        //Create menu container
        AnchorPane menuContainer = new AnchorPane();
        menuContainer.setId("menu-container");
        
        //Create layout within menu
        VBox menuContent = new VBox();
        menuContent.setId("side-menu");//id for css styling

       
        //Show user details on top left side of menu content
        //First name
        Text firstName = new Text();
        firstName.setText(currentUser.getFirstName());
        firstName.setId("usernameTitle");
        menuContent.getChildren().add(firstName);
        
        //Last name
        Text lastName = new Text();
        lastName.setText(currentUser.getLastName());
        lastName.setId("usernameTitle");
        menuContent.getChildren().add(lastName);
        
        //Username
        Text username = new Text();
        username.setText("Username: "+currentUser.getUsername());
        username.setId("usernameTitle");
        menuContent.getChildren().add(username);
        
        //Role
        Text role = new Text();
        role.setText("Role: Course Staff");
        role.setId("usernameTitle");
        menuContent.getChildren().add(role);
        
        //Add components to menu content layout
        Text menuTitle = new Text("Menu");
        menuTitle.setId("menuTitle");//for css
        VBox.setMargin(menuTitle, new Insets(60, 0, 0, 0));
        menuContent.getChildren().add(menuTitle);
        
        menuContent.setPadding(new Insets(30));
        menuContent.setSpacing(8);
        

        
        //create buttons for side menu
        menuOptions = new Button[] {
            new Button("Create course"),
            new Button("Deactivate course"),
            new Button("Update course"),
            new Button("Log Out")
        };
        
        
        
        for (Button option : menuOptions) {
            option.setOnAction(this);
            if(option.getText().equals("Log Out")){
                option.setId("logout");
                VBox.setMargin(option, new Insets(300, 0, 0, 65));
            }
            else{
                option.setId("menu-buttons");
                VBox.setMargin(option, new Insets(5, 0, 0, 40));
            }
            menuContent.getChildren().add(option);
        }
         
        //menu will be 95% away from right side of screen dimensions
        AnchorPane.setRightAnchor(menuContent, screenSize.getWidth() - (0.95*screenSize.getWidth()));
        menuContainer.getChildren().add(menuContent);
        
        return menuContainer;
    }
    
    //gets the create course screen for course staff
    public GridPane getCreateCourseScreen(){
        //layout
        GridPane formLayout = new GridPane();
        formLayout.setAlignment(Pos.CENTER);
        formLayout.setHgap(10);
        formLayout.setVgap(10);
        formLayout.setPadding(new Insets(25, 25, 25, 25));    
        formLayout.setId("main-side");//id for css styling
        
        Text test = new Text("Create Course:");
        test.setId("test");
        
        Label courseNameLabel = new Label("Course Name:");
        courseNameLabel.setId("create-course-labels");
        TextField courseNameBar = new TextField();
        courseNameBar.setId("searchBar");
        formLayout.add(courseNameLabel, 0, 1);
        formLayout.add(courseNameBar, 1, 1);
        
        Label courseStatusLabel = new Label("Course Status:");
        courseStatusLabel.setId("create-course-labels");
        String[] statusOp = {"Active", "Inactive"};
        ComboBox courseStatusOptions = new ComboBox(FXCollections.observableArrayList(statusOp));
        formLayout.add(courseStatusLabel, 0, 2);
        formLayout.add(courseStatusOptions, 1, 2);
        
        Label courseIDLabel = new Label("Course ID:");
        courseIDLabel.setId("create-course-labels");
        TextField courseIDBar = new TextField();
        courseIDBar.setId("searchBar");
        formLayout.add(courseIDLabel, 0, 3);
        formLayout.add(courseIDBar, 1, 3);
        
        //Confirm message properties
        confirmMessage = new Text();
        confirmMessage.setId("confirm-message");
        formLayout.add(confirmMessage, 1, 4);
        
  
        Button create = new Button("Create");
        create.setOnAction( e -> {
            
            String inputName = courseNameBar.getText();
            String inputID = courseIDBar.getText();
            if(courseStatusOptions.getValue() == null){
                System.out.println("Please select status");
            }
            else if(inputName.isEmpty()){
                System.out.println("Please enter a course name");
            }
            else if(inputID.isEmpty()){
                System.out.println("Please enter ID");
            }
            else{
                String inputStatus = ""+courseStatusOptions.getValue();
                boolean status;
                //get boolean of course status
                if(inputStatus.equals("Active")){
                    status = true;
                }
                else{
                    status = false;
                }


                boolean exist = false;

                //check against all trainer objects
                for (Course course : Course.getCourseList()) {
                    if(inputName.equals(course.getCourseName()) || inputName.equals(course.getCourseID())){
                        //if search matches username or id of a trainer
                        System.out.println("Course already exist");
                        exist = true;
                        break;            
                    }

                }
              
                if (!exist){
                    //Create course object and add to database
                    Course course = new Course(inputName, inputID, status);
                    Course.addToCourseList(course);
                    CourseStaff.addCourseToDatabase(course);
                    confirmMessage.setText("Course created");
                }
            }
        });
        
        formLayout.add(create, 0, 4);
        
        return formLayout;
        
    }
    
    public void addStyleSheet(Scene scene){
        scene.getStylesheets().add(Trainer.class.getResource("UserScreen.css").toExternalForm());
        //links this scene object to css file
    }
}
