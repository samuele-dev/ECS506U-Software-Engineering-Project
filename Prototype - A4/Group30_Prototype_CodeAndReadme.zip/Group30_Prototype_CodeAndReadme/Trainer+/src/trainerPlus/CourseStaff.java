
package trainerPlus;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author tony
 */
public class CourseStaff {
    
    private String username;
    private String ID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    
    private static ArrayList<CourseStaff> courseStaff;
    
    public CourseStaff(String uName, String identifier, String fName, String lName, String mail, String phone){
        username = uName;
        ID = identifier;
        firstName = fName;
        lastName = lName;
        email = mail;
        phoneNumber = phone;
    
    }
    
    //function to return the ID of current object
    public String getID(){
        return ID;
    }
    
    //function to return the username of current object
    public String getUsername(){
        return username;
    }
    
    //This function returns the first name of this user
    public String getFirstName(){
        return firstName;
    }
    
    //This function returns the last name of this user
    public String getLastName(){
        return lastName;
    }
    
    //This function returns the email for this user
    public String getEmail(){
        return email;
    }
    
    //This function returns the phone number for this user
    public String getPhoneNumber(){
        return phoneNumber;
    }
    
    
    
    
    
    
    //static methods
    
    //method to add a course object properties to database
    public static void addCourseToDatabase(Course course){
        String name = course.getCourseName();
        String id = course.getCourseID();
        boolean st = course.getStatus();
        String status;
        if(st == true){
            status = "Active";
        }
        else{
            status = "Inactive";
        }
        
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");

            String insert = "INSERT INTO USERNAME.COURSES VALUES (?, ?, ?)";

            //create java prepared statement so we can update data in table using data given from user
            PreparedStatement statement = con.prepareStatement(insert);

            //add course details to database
            statement.setString(1, id);
            statement.setString(2, name);
            statement.setString(3, status);

            statement.executeUpdate();
            statement.close();
            //System.out.println("successful adding course: " + name + "to database");
        } catch (Exception e) {
            System.out.println("error: "+ e);
        }
    }
    
    //Loads course data from database
    public static void getCourseData(){
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");

            String query = "SELECT * FROM USERNAME.COURSES";

            //create java statement
            Statement statement = con.createStatement();

            ResultSet record = statement.executeQuery(query);
            
            //iterate through every record
            while(record.next()){
                String courseID = record.getString("ID");
                String courseName = record.getString("NAME");
                Boolean courseStatus = record.getBoolean("STATUS");
                Course c1 = new Course(courseName, courseID, courseStatus);
                Course.addToCourseList(c1);
            }
            
            statement.close();  
            
        } catch (Exception e) {
            System.out.println("Error getting course details");
            System.out.println(e);
            
        }
    }
    
    //create a new arraylist of type AssignStaff
    public static void createList(){
        courseStaff = new ArrayList<CourseStaff>();
    }
    
    //add an assignstaff object to the list of AssignStaff objects
    public static void addCourseStaffToList(CourseStaff user){
        courseStaff.add(user);
        
    }
    
    //return list of AssignStaff objects
    public static ArrayList<CourseStaff> getListOfCourseStaff(){
        return courseStaff;
    }
    
}
