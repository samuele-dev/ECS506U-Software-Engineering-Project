
package trainerPlus;

/**
 *
 * @author adil
 */
public class Session {
    
    private String name;
    private String startTime;
    private String endTime;
    private String week;
    private String day;
    private String location;
    
    
    
    public Session(String n, String startT, String endT, String wk, String d, String loc){
        name = n;
        startTime = startT;
        endTime = endT;
        week = wk;
        day = d;
        location = loc;
        
    }
    
    public String getName(){
        return name;
    }
    
    public String getStartTime(){
        return startTime;
    }
    
    public String getEndTime(){
        return endTime;
    }
    
    public String getWeek(){
        return week;
    }
    
    public String getDay(){
        return day;
    }
    
    public String getLocation(){
        return location;
    }

    
}
