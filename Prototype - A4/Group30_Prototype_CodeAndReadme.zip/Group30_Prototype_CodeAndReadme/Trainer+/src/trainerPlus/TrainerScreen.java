
package trainerPlus;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author adil
 */
public class TrainerScreen implements EventHandler<ActionEvent>{
    
    //Stage declaration
    private Stage window;
    
    
    //Declaration of object to get screen size
    private Rectangle2D screenSize;
    
    //For editing personal details screen
    //Label declarations
    private Label firstnameLabel;
    private Label lastnameLabel;
    private Label usernameLabel;
    private Label ID;
    private Label emailLabel;
    private Label phoneLabel;

    private Text errorMessage;

    //Text and TextField declaration
    private Text firstnameText;
    private Text lastnameText;
    private Text usernameText;
    private Text IDText;
    private Text emailText;
    private Text phoneText;
    private TextField emailInput;
    private TextField phoneInput;
   
    //button declarations
    private Button save;
    private Button cancel;
    
    //end of personal details screen
    
   
    //Menu buttons declarations
    private Button[] menuOptions;
    
    
    private Trainer currentTrainer;
    
    //has to be global week number to this object, otherwise button wouldn't be able
    //to access it
    private int weekNo = 1;//always start at week 1 but change according to next/previous week pressed
    //button declaration for schedule screen
    private Button nextWeek;
    private Button prevWeek;
            
            
    
    
    public TrainerScreen(Trainer current){
        currentTrainer = current;
        window = new Stage();
        window.setTitle("FDM Trainer+");
        
        screenSize = Screen.getPrimary().getVisualBounds();//gets dimensions of your computer screen
        
        BorderPane screen = new BorderPane();
        AnchorPane main = getMainScreen();
        //get default content on login
        GridPane content = getUserHomeScreen();
        main.getChildren().add(content);
        
        screen.setLeft(getMenuScreen());
        screen.setCenter(main);
        
        //screen.getChildren().addAll(menuContainer, mainContainer);
        Scene scene = new Scene(screen, screenSize.getWidth(), screenSize.getHeight());
        
        addStyleSheet(scene);
        
        
        window.setScene(scene);
        window.show();
    
    }
    
    
    @Override
    public void handle(ActionEvent event) {
        if(event.getSource() == menuOptions[0]){
            //view alerts option
            
            
            BorderPane newScreen = new BorderPane();
            AnchorPane main = getMainScreen();
            VBox content = getViewAlertsContent();
            main.getChildren().add(content);
            
           
            newScreen.setLeft(getMenuScreen());
            newScreen.setCenter(main);
            Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
            addStyleSheet(scene2);
            window.setScene(scene2);
            
        }
        else if(event.getSource() == menuOptions[2]){
            //view schedule option       
            BorderPane newScreen = new BorderPane();
            AnchorPane main = getMainScreen();
            GridPane content = getScheduleContent();
            main.getChildren().add(content);
            
           
            newScreen.setLeft(getMenuScreen());
            newScreen.setCenter(main);
            Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
            addStyleSheet(scene2);
            window.setScene(scene2);
            
        }
        else if(event.getSource() == menuOptions[1]){
            //Edit profile option
            
            BorderPane newScreen = new BorderPane();
            AnchorPane main = getMainScreen();
            GridPane content = getEditProfileContent();
            main.getChildren().add(content);
            
           
            newScreen.setLeft(getMenuScreen());
            newScreen.setCenter(main);
            Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
            addStyleSheet(scene2);
            window.setScene(scene2);
            
        }
        else if(event.getSource() == menuOptions[3]){
            //View Course info option
            
            
            BorderPane newScreen = new BorderPane();
            AnchorPane main = getMainScreen();
            VBox content = getCoursesInfoContent();
            main.getChildren().add(content);
            
           
            newScreen.setLeft(getMenuScreen());
            newScreen.setCenter(main);
            Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
            addStyleSheet(scene2);
            window.setScene(scene2);
           
        }
        else if (event.getSource() == menuOptions[4]){
            //log out pressed
            new Welcome();
            window.close();
        }
        else if(event.getSource() == prevWeek){
            if(weekNo != 1){
                weekNo--;//decrement week number
                //view new schedule        
                BorderPane newScreen = new BorderPane();
                AnchorPane main = getMainScreen();
                GridPane content = getScheduleContent();
                main.getChildren().add(content);


                newScreen.setLeft(getMenuScreen());
                newScreen.setCenter(main);
                Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
                addStyleSheet(scene2);
                window.setScene(scene2);
            }
            else{
                System.out.println("You are at the minimum week.");
            }
        }
        else if(event.getSource() == nextWeek){
            if(weekNo != 12){
                weekNo++;//increment week number
                
                //view new schedule for the new week        
                BorderPane newScreen = new BorderPane();
                AnchorPane main = getMainScreen();
                GridPane content = getScheduleContent();
                main.getChildren().add(content);


                newScreen.setLeft(getMenuScreen());
                newScreen.setCenter(main);
                Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
                addStyleSheet(scene2);
                window.setScene(scene2);
                
            }
            else{
                System.out.println("You're at the last week of training course");
            }
        }
        
    }
    
    //Function to get the default screen so it is easier to switch between scenes
    public AnchorPane getMainScreen(){
       
        //Main content
        //Create main screen container
        AnchorPane mainContainer = new AnchorPane();
        mainContainer.setId("main-container");

        
        return mainContainer;
    
    }
    
    public AnchorPane getMenuScreen(){
        //Create menu container
        AnchorPane menuContainer = new AnchorPane();
        menuContainer.setId("menu-container");
        
        //Create layout within menu
        VBox menuContent = new VBox();
        menuContent.setId("side-menu");//id for css styling
        
        
        //Show user details on top left side of menu content
        //First name
        Text firstName = new Text();
        firstName.setText(currentTrainer.getFirstName());
        firstName.setId("usernameTitle");
        menuContent.getChildren().add(firstName);
        
        //Last name
        Text lastName = new Text();
        lastName.setText(currentTrainer.getLastName());
        lastName.setId("usernameTitle");
        menuContent.getChildren().add(lastName);
        
        //Username
        Text username = new Text();
        username.setText("Username: "+currentTrainer.getUsername());
        username.setId("usernameTitle");
        menuContent.getChildren().add(username);
        
        //Role
        Text role = new Text();
        role.setText("Role: Trainer");
        role.setId("usernameTitle");
        menuContent.getChildren().add(role);
        
        //Add components to menu content layout
        Text menuTitle = new Text("Menu");
        menuTitle.setId("menuTitle");//for css
        VBox.setMargin(menuTitle, new Insets(50, 0, 0, 0));
        menuContent.getChildren().add(menuTitle);        
        
        menuContent.setPadding(new Insets(30));
        menuContent.setSpacing(8);
        
        //create buttons for side menu
        menuOptions = new Button[] {
            new Button("View Alerts"),
            new Button("Edit Profile"),
            new Button("View Schedule"),
            new Button("View Course Info"),
            new Button("Log Out")
                
        };
        
        
        //set properties for each button in menu
        for (Button option : menuOptions) {
            option.setOnAction(this);
            if(option.getText().equals("Log Out")){
                option.setId("logout");
                VBox.setMargin(option, new Insets(250, 0, 0, 65));
            }
            else{
                option.setId("menu-buttons");
                VBox.setMargin(option, new Insets(5, 0, 0, 40));
            }
            
            menuContent.getChildren().add(option);
            
        }
            
        
        
        //add everything in vbox layout to the anchorpane (i.e. contents of menu into menu container)
       
        //menu will be 95% away from right side of screen dimensions
        AnchorPane.setRightAnchor(menuContent, screenSize.getWidth() - (0.95*screenSize.getWidth()));
        menuContainer.getChildren().add(menuContent);
        
        return menuContainer;
    }
    
    public GridPane getUserHomeScreen(){
        GridPane layout = new GridPane();
        layout.setId("edit-details");
        layout.setAlignment(Pos.CENTER);
        layout.setHgap(10);
        layout.setVgap(10);
        layout.setPadding(new Insets(25, 25, 25, 25));    
        
        //FDM ID 
        ID = new Label("FDM ID:");
        
        layout.add(ID, 0, 1);

        IDText = new Text(currentTrainer.getID());
        IDText.setId("user-details-text");
        layout.add(IDText, 1, 1);
        
        //First name
        firstnameLabel = new Label("First Name:");
        layout.add(firstnameLabel, 0, 2);

        firstnameText = new Text(currentTrainer.getFirstName());
        firstnameText.setId("user-details-text");
        layout.add(firstnameText, 1, 2);
        
        //Last name 
        lastnameLabel = new Label("Last Name:");
        layout.add(lastnameLabel, 0, 3);

        lastnameText = new Text(currentTrainer.getLastName());
        lastnameText.setId("user-details-text");
        layout.add(lastnameText, 1, 3);
        
        //Username
        usernameLabel = new Label("Username:");
        layout.add(usernameLabel, 0, 4);

        usernameText = new Text(currentTrainer.getUsername());
        usernameText.setId("user-details-text");
        layout.add(usernameText, 1, 4);
        
        //Email
        emailLabel = new Label("Email:");
        layout.add(emailLabel, 0, 5);

        emailText = new Text(currentTrainer.getEmail());
        emailText.setId("user-details-text");
        layout.add(emailText, 1, 5);
        
        //Phone number
        phoneLabel = new Label("Phone No.:");
        layout.add(phoneLabel, 0, 6);

        phoneText = new Text(currentTrainer.getPhoneNumber());
        phoneText.setId("user-details-text");
        layout.add(phoneText, 1, 6);

        
        return layout;
    }
    
    public VBox getViewAlertsContent(){
        //Create layout within main content
        VBox mainContent = new VBox();
        mainContent.setId("main-side");//id for css styling
        
        mainContent.setPadding(new Insets(10));
        mainContent.setSpacing(8);
        
        
        System.out.println("view alerts was pressed");
        Text test = new Text("No Alerts");
        test.setId("test");
        
        mainContent.getChildren().add(test);
        
        return mainContent;
    }
    
    //This function will return the schedule for the specified week
    public GridPane getScheduleContent(){
        
        //Create layout within main content
        GridPane mainContent = new GridPane();
        mainContent.setId("schedule");//id for css styling
        mainContent.setVgap(50);//set vertical spacing between grid cells
        mainContent.setHgap(30);//set horizontal spacing between grid cells
        mainContent.setPadding(new Insets(20, 20, 20, 20));//set insets
        
        
        //get calendar for this user
        mainContent = Calendar.getCalendar(currentTrainer, weekNo, "trainer");
        //get number of sessions for each day for this week to change position
        //of next week button accordingly
        int noSesMonday = Calendar.getNumberOfMondaySessions();
        int noSesTuesday = Calendar.getNumberOfTuesdaySessions();
        int noSesWednesday = Calendar.getNumberOfWednesdaySessions();
        int noSesThursday = Calendar.getNumberOfThursdaySessions();
        int noSesFriday = Calendar.getNumberOfFridaySessions();
        
        int daysWithSessions = getNoDaysThatHaveSessions(noSesMonday, noSesTuesday, noSesWednesday, noSesThursday, noSesFriday);
        
        //Next week and previous week buttons
        //These are to navigate between weeks of schedules
        prevWeek = new Button("Previous Week");
        nextWeek = new Button("Next Week");
  
        //actions for the previous week button
        prevWeek.setOnAction(this);
      
        //action for the next week button
        nextWeek.setOnAction(this);
          
        
        mainContent.add(prevWeek, 0, 1);

        switch (daysWithSessions) {
            case 0:
                //return here if no sessions exist for this week
                mainContent.add(nextWeek, 10, 1);
                return mainContent;
            case 1:
                mainContent.add(nextWeek, 8, 1);
                break;
            case 2:
                mainContent.add(nextWeek, 7, 1);
                break;
            case 3:
                mainContent.add(nextWeek, 6, 1);
                break;
            case 4:
                mainContent.add(nextWeek, 5, 1);
                break;
            default:
                //for 5 or more i.e. all days have at least a sesssion so next
                //week button must not be placed too far to the right
                mainContent.add(nextWeek, 5, 1);
                break;
        }
 
        
        return mainContent;
    }
    
    //This function returns how many of the 5 days in work week has a session (at least)
    public int getNoDaysThatHaveSessions(int monday, int tuesday, int wednesday, int thursday, int friday){
        int daysWithSessions = 0;
        if(monday>0){
            daysWithSessions++;
        }
        if(tuesday>0){
            daysWithSessions++;
        }
        if(wednesday>0){
            daysWithSessions++;
        }
        if(thursday>0){
            daysWithSessions++;
        }
        if(friday>0){
            daysWithSessions++;
        }
        
        return daysWithSessions;
    }
    
    
    public GridPane getEditProfileContent(){
        //Create layout within main content
        GridPane layout = new GridPane();
        layout.setId("edit-details");
        layout.setAlignment(Pos.CENTER);
        layout.setHgap(10);
        layout.setVgap(10);
        layout.setPadding(new Insets(25, 25, 25, 25));    
        
        //FDM ID 
        ID = new Label("FDM ID:");
        
        layout.add(ID, 0, 1);

        IDText = new Text(currentTrainer.getID());
        IDText.setId("user-details-text");
        layout.add(IDText, 1, 1);
        
        //First name
        firstnameLabel = new Label("First Name:");
        layout.add(firstnameLabel, 0, 2);

        firstnameText = new Text(currentTrainer.getFirstName());
        firstnameText.setId("user-details-text");
        layout.add(firstnameText, 1, 2);
        
        //Last name 
        lastnameLabel = new Label("Last Name:");
        layout.add(lastnameLabel, 0, 3);

        lastnameText = new Text(currentTrainer.getLastName());
        lastnameText.setId("user-details-text");
        layout.add(lastnameText, 1, 3);
        
        //Username
        usernameLabel = new Label("Username:");
        layout.add(usernameLabel, 0, 4);

        usernameText = new Text(currentTrainer.getUsername());
        usernameText.setId("user-details-text");
        layout.add(usernameText, 1, 4);
        
        //Email
        emailLabel = new Label("Email:");
        layout.add(emailLabel, 0, 5);

        emailInput = new TextField();
        layout.add(emailInput, 1, 5);
        
        //Phone number
        phoneLabel = new Label("Phone No.:");
        layout.add(phoneLabel, 0, 6);

        phoneInput = new TextField();
        layout.add(phoneInput, 1, 6);
        
        

        //error message properties
        errorMessage = new Text();
        errorMessage.setId("error-Message");
        layout.add(errorMessage, 1, 9);


        //Buttons' properties
        save = new Button("Save Changes");
        layout.add(save, 1, 10);
        
        cancel = new Button("Cancel");
        layout.add(cancel, 0, 10);
        //register.setBounds(700, 430, 110, 20);
        
        save.setOnAction(this);
        cancel.setOnAction(this);
        
        return layout;
    }
    
    public VBox getCoursesInfoContent(){
        //Create layout within main content
        VBox mainContent = new VBox();
        mainContent.setId("main-side");//id for css styling
        
        mainContent.setPadding(new Insets(10));
        mainContent.setSpacing(8);
        
        
        
        System.out.println("View Course Info was pressed");
        Text test = new Text("Courses Information:");
        test.setId("test");
 
        mainContent.getChildren().add(test);
        
        return mainContent;
    }
    
    public void addStyleSheet(Scene scene){
        scene.getStylesheets().add(Trainer.class.getResource("UserScreen.css").toExternalForm());
        //links this scene object to css file
    }
    
}
