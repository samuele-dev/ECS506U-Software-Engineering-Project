
package trainerPlus;

import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author adil
 */
public class AssignStaffScreen implements EventHandler<ActionEvent>{
    
    private AssignStaff currentUser;
    private String tID;
    
    private Stage window;
    private Rectangle2D screenSize;
    
    private Button[] menuOptions;

    
    //For add session form:
    
    //Label declarations
    private Label sessionNameLabel;
    private Label startTimeLabel;
    private Label endTimeLabel;
    private Label weekLabel;
    private Label dayLabel;
    private Label locationLabel;

    
    //ComboBox declarations for adding a session
    private ComboBox sessionNameChoices; 
    private ComboBox startTimeChoices;
    private ComboBox endTimeChoices;
    private ComboBox weekNoChoices;
    private ComboBox dayChoices;
    private ComboBox locationChoices;
    
    //variables for dropbox selections
    private String currentSessionName;
    private int currentStartTime;
    private int currentEndTime;
    private String currentWeek;
    
    
    private final String[] endTimes = {"10:00", "11:00", "12:00", "13:00", "14:00", "15:00"};
    private final String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    
    private Text confirmMessage;
    
    private Button addSession;
    
    //End of add session form declarations
    
    
    //For when user is found/searched for:
    private TextField searchBar;
    private Button findTrainer;
    private String modeView = "Cal";
    private Button viewCal;
    private Button addSes;
    
        //For schedule of user:

        //has to be global week number to this object, otherwise button wouldn't be able
        //to access it
        private int weekNo = 1;//always start at week 1 but change according to next/previous week pressed
        //button declarations for schedule screen
        private Button nextWeek;
        private Button prevWeek;

        //end of schedule
        
    //end of user search screen
    
    public AssignStaffScreen(AssignStaff current){
        currentUser = current;
        window = new Stage();
        window.setTitle("FDM Trainer+");
        
        screenSize = Screen.getPrimary().getVisualBounds();//gets dimensions of your computer screen
        
        BorderPane screen = new BorderPane();
        screen.setLeft(getMenuScreen());
        screen.setCenter(getMainScreen());
        
        Scene scene = new Scene(screen, screenSize.getWidth(), screenSize.getHeight());
        
        addStyleSheet(scene);
        
        
        window.setScene(scene);
        window.show();
        
    
    }
    
    @Override
    public void handle(ActionEvent event) {
        if(event.getSource() == menuOptions[0]){
            //search trainer button pressed
 
            BorderPane newScreen = new BorderPane();
            AnchorPane main = getMainScreen();
            
            VBox content = getSearchTrainerScreen();
            content.setId("search-trainer-screen");
            main.getChildren().add(content);
             
            newScreen.setLeft(getMenuScreen());
            newScreen.setCenter(main);
            
            Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
            addStyleSheet(scene2);
            window.setScene(scene2);
            
            
            
        }
        else if(event.getSource() == menuOptions[1]){
            //Search trainee pressed
        }
        else if(event.getSource() == menuOptions[2]){
            //log out pressed
            new Welcome();
            window.close();
        }
        else if(event.getSource() == findTrainer){
            String input = searchBar.getText();
            boolean found = false;
   
            //check against all trainer objects
            for (Trainer trainer : Trainer.getListOfTrainers()) {
                if(input.equals(trainer.getUsername()) || input.equals(trainer.getID())){
                    //if search matches username or id of a trainer
                    //System.out.println("user found");
                    found = true;
                    tID = trainer.getID();
                    break;
                    
                }
                
            }
            
            if (!found){
                System.out.println("Sorry your search didn't match any users");
                BorderPane newScreen = new BorderPane();
                AnchorPane main = getMainScreen();

                VBox content = getSearchTrainerScreen();
                content.setId("search-trainer-screen");
                main.getChildren().add(content);


                newScreen.setLeft(getMenuScreen());
                newScreen.setCenter(main);

                Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
                addStyleSheet(scene2);
                window.setScene(scene2);
                
                
            }
            else{
                VBox mainContent = getSearchTrainerScreen();
                //display user's schedule
                Text user = new Text("Trainer: "+Trainer.getTrainer(tID).getUsername());
                user.setId("found-username");
                GridPane scheduleContent = getScheduleContent(weekNo);
                GridPane formLayout = getAddSessionForm(tID);
                
               
                HBox userActions = new HBox();
                viewCal = new Button("View Schedule");
                addSes = new Button("Add Session");
                userActions.getChildren().clear();
                userActions.getChildren().addAll(viewCal, addSes);
                
                mainContent.getChildren().addAll(user, userActions, scheduleContent);
                
                viewCal.setOnAction(e -> {
                    
                    if(!modeView.equals("Cal")){
                        //change back to calendar from add session    
                        GridPane newScheduleContent = getScheduleContent(weekNo);
                        mainContent.getChildren().add(newScheduleContent);
                        if(mainContent.getChildren().contains(formLayout)){
                            //remove add session form if it is there
                            mainContent.getChildren().remove(formLayout);
                        }
                        
                    }
                    
                    modeView = "Cal";
                });
                
                addSes.setOnAction(e -> {
                    if(modeView.equals("Cal")){
                        //display a different screen (form for filling out session) for that user
                        mainContent.getChildren().add(formLayout);
                        if(mainContent.getChildren().contains(scheduleContent)){
                            //remove start schedule
                            mainContent.getChildren().remove(scheduleContent);
                        }
                        else{
                            mainContent.getChildren().remove(mainContent.getChildren().size()-2);
                            //remove new schedule
                        }
                      
                       
                    }
                    modeView = "AddSes";
                });
                
                
                BorderPane newScreen = new BorderPane();
                AnchorPane main = getMainScreen();

                
                mainContent.setId("search-trainer-screen");
                main.getChildren().add(mainContent);


                newScreen.setLeft(getMenuScreen());
                newScreen.setCenter(main);

                Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
                addStyleSheet(scene2);
                window.setScene(scene2);

                
            }
        
        }
        else if(event.getSource() == prevWeek){
            if(weekNo != 1){
                weekNo--;//decrement week number
                //view new schedule        
                VBox mainContent = getSearchTrainerScreen();
                //display user's schedule
                Text user = new Text("Trainer: "+Trainer.getTrainer(tID).getUsername());
                user.setId("found-username");
                GridPane scheduleContent = getScheduleContent(weekNo);
                GridPane formLayout = getAddSessionForm(tID);
                
                HBox userActions = new HBox();
                viewCal = new Button("View Schedule");
                addSes = new Button("Add Session");
                userActions.getChildren().clear();
                userActions.getChildren().addAll(viewCal, addSes);
                
                mainContent.getChildren().addAll(user, userActions, scheduleContent);
                
                viewCal.setOnAction(e -> {
                    
                    if(!modeView.equals("Cal")){
                        if(mainContent.getChildren().contains(scheduleContent)){
                            mainContent.getChildren().remove(scheduleContent);
                            //remove schedule content if it is from start there
                        }
                        //change back to calendar from add session    
                        GridPane newScheduleContent = getScheduleContent(weekNo);
                        mainContent.getChildren().addAll(newScheduleContent);
                        if(mainContent.getChildren().contains(formLayout)){
                            //remove add session form if it is there
                            mainContent.getChildren().remove(formLayout);
                        }
                        
                    }
                    
                    modeView = "Cal";
                });
                
                addSes.setOnAction(e -> {
                    if(modeView.equals("Cal")){
                        //display a different screen (form for filling out session) for that user
                        mainContent.getChildren().add(formLayout);
                        if(mainContent.getChildren().contains(scheduleContent)){
                            //remove start schedule
                            mainContent.getChildren().remove(scheduleContent);
                        }
                        else{
                            mainContent.getChildren().remove(mainContent.getChildren().size()-2);
                            //remove new schedule
                        }
                    }
                    modeView = "AddSes";
                });
                
                
                BorderPane newScreen = new BorderPane();
                AnchorPane main = getMainScreen();

                
                mainContent.setId("search-trainer-screen");
                main.getChildren().add(mainContent);


                newScreen.setLeft(getMenuScreen());
                newScreen.setCenter(main);

                Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
                addStyleSheet(scene2);
                window.setScene(scene2);
                
            
            }
            else{
                System.out.println("You are at the minimum week.");
            }
        }
        else if(event.getSource() == nextWeek){
            if(weekNo != 12){
                weekNo++;//increment week number
                
                //view new schedule for the new week        
                VBox mainContent = getSearchTrainerScreen();
                //display user's schedule
                Text user = new Text("Trainer: "+Trainer.getTrainer(tID).getUsername());
                user.setId("found-username");
                GridPane scheduleContent = getScheduleContent(weekNo);
                GridPane formLayout = getAddSessionForm(tID);
                
                HBox userActions = new HBox();
                viewCal = new Button("View Schedule");
                addSes = new Button("Add Session");
                userActions.getChildren().clear();
                userActions.getChildren().addAll(viewCal, addSes);
                
                mainContent.getChildren().addAll(user, userActions, scheduleContent);
                
                viewCal.setOnAction(e -> {
                    
                    if(!modeView.equals("Cal")){
                        if(mainContent.getChildren().contains(scheduleContent)){
                            mainContent.getChildren().remove(scheduleContent);
                            //remove schedule content if it is from start there
                        }
                        //change back to calendar from add session    
                        GridPane newScheduleContent = getScheduleContent(weekNo);
                        mainContent.getChildren().addAll(newScheduleContent);
                        if(mainContent.getChildren().contains(formLayout)){
                            //remove add session form if it is there
                            mainContent.getChildren().remove(formLayout);
                        }
                        
                    }
                    
                    modeView = "Cal";
                });
                
                addSes.setOnAction(e -> {
                    if(modeView.equals("Cal")){
                        //display a different screen (form for filling out session) for that user
                        mainContent.getChildren().add(formLayout);
                        if(mainContent.getChildren().contains(scheduleContent)){
                            //remove start schedule
                            mainContent.getChildren().remove(scheduleContent);
                        }
                        else{
                            mainContent.getChildren().remove(mainContent.getChildren().size()-2);
                            //remove new schedule
                        }
                    }
                    modeView = "AddSes";
                });
                
                
                BorderPane newScreen = new BorderPane();
                AnchorPane main = getMainScreen();

                
                mainContent.setId("search-trainer-screen");
                main.getChildren().add(mainContent);


                newScreen.setLeft(getMenuScreen());
                newScreen.setCenter(main);

                Scene scene2 = new Scene(newScreen, screenSize.getWidth(), screenSize.getHeight());
                addStyleSheet(scene2);
                window.setScene(scene2);
                
                
            }
            else{
                System.out.println("You're at the last week of training course");
            }
        }
        
    }
    
    //Function to get the default screen so it is easier to switch between scenes
    public AnchorPane getMainScreen(){
        //Create main screen container
        AnchorPane mainContainer = new AnchorPane();
        mainContainer.setId("main-container");//id for css styling
        
        
        return mainContainer;
    }
    
    public AnchorPane getMenuScreen(){
        //Create menu container
        AnchorPane menuContainer = new AnchorPane();
        menuContainer.setId("menu-container");
        
        //Create layout within menu
        VBox menuContent = new VBox();
        menuContent.setId("side-menu");//id for css styling
        
        
        //Show user details on top left side of menu content
        //First name
        Text firstName = new Text();
        firstName.setText(currentUser.getFirstName());
        firstName.setId("usernameTitle");
        menuContent.getChildren().add(firstName);
        
        //Last name
        Text lastName = new Text();
        lastName.setText(currentUser.getLastName());
        lastName.setId("usernameTitle");
        menuContent.getChildren().add(lastName);
        
        //Username
        Text username = new Text();
        username.setText("Username: "+currentUser.getUsername());
        username.setId("usernameTitle");
        menuContent.getChildren().add(username);
        
        //Role
        Text role = new Text();
        role.setText("Role: Assign Staff");
        role.setId("usernameTitle");
        menuContent.getChildren().add(role);
        
        //Add components to menu content layout
        Text menuTitle = new Text("Menu");
        menuTitle.setId("menuTitle");//for css
        VBox.setMargin(menuTitle, new Insets(70, 0, 0, 0));
        menuContent.getChildren().add(menuTitle);
        
        menuContent.setPadding(new Insets(30));
        menuContent.setSpacing(8);
        

        
        //create buttons for side menu
        menuOptions = new Button[] {
            new Button("Search Trainer"),
            new Button("Search Trainee"),
            new Button("Log Out"),
        };
        
        
        //set properties for each button in menu
        for (Button option : menuOptions) {
            option.setOnAction(this);
            if(option.getText().equals("Log Out")){
                option.setId("logout");
                VBox.setMargin(option, new Insets(340, 0, 0, 65));
            }
            else{
                option.setId("menu-buttons");
                VBox.setMargin(option, new Insets(5, 0, 0, 40));
            }
            menuContent.getChildren().add(option);
        }
            
        
        //menu will be 95% away from right side of screen dimensions
        AnchorPane.setRightAnchor(menuContent, screenSize.getWidth() - (0.95*screenSize.getWidth()));
        menuContainer.getChildren().add(menuContent);
        
        return menuContainer;
    }
    
    
    public VBox getSearchTrainerScreen(){
        //layout
        VBox mainContent = new VBox();
        mainContent.setId("main-side");//id for css styling
        
        mainContent.setPadding(new Insets(10));
        mainContent.setSpacing(8);
        
        Label title = new Label("Search:");
        
        searchBar = new TextField();
        searchBar.setId("search-bar");
        
        findTrainer = new Button("Find Trainer");
        findTrainer.setOnAction(this);
        
      
        if(mainContent.getChildren().isEmpty()){
            //if it is empty then the user search didnt match anything,
            //so add the normal content here
            //here the display is search trainer 
            mainContent.getChildren().addAll(title, searchBar, findTrainer);   
        }
     
        
        return mainContent;
        
    }
    
    //This function will return the schedule for the specified week
    public GridPane getScheduleContent(int weekNum){
        
        //Create layout within main content
        GridPane mainContent = new GridPane();
        mainContent.setId("schedule");//id for css styling
        mainContent.setVgap(50);//set vertical spacing between grid cells
        mainContent.setHgap(30);//set horizontal spacing between grid cells
        mainContent.setPadding(new Insets(20, 20, 20, 20));//set insets
        
        
        //get calendar for this user
        Trainer trainer = Trainer.getTrainer(tID);
        mainContent = Calendar.getCalendar(trainer, weekNum, "assign");
  
        //get number of sessions for each day for this week to change position
        //of next week button accordingly
        int noSesMonday = Calendar.getNumberOfMondaySessions();
        int noSesTuesday = Calendar.getNumberOfTuesdaySessions();
        int noSesWednesday = Calendar.getNumberOfWednesdaySessions();
        int noSesThursday = Calendar.getNumberOfThursdaySessions();
        int noSesFriday = Calendar.getNumberOfFridaySessions();
        
        int daysWithSessions = getNoDaysThatHaveSessions(noSesMonday, noSesTuesday, noSesWednesday, noSesThursday, noSesFriday);
        
        
        //Next week and previous week buttons
        //These are to navigate between weeks of schedules
        prevWeek = new Button("Previous Week");
        nextWeek = new Button("Next Week");
  
        //actions for the previous week button
        prevWeek.setOnAction(this);
      
        //action for the next week button
        nextWeek.setOnAction(this);

        mainContent.add(prevWeek, 0, 1);

        switch (daysWithSessions) {
            case 0:
                //return here if no sessions exist for this week
                mainContent.add(nextWeek, 15, 1);
                break;
            case 1:
                mainContent.add(nextWeek, 9, 1);
                break;
            case 2:
                mainContent.add(nextWeek, 7, 1);
                break;
            case 3:
                mainContent.add(nextWeek, 5, 1);
                break;
            case 4:
                mainContent.add(nextWeek, 5, 1);
                break;
            default:
                //for 5 or more i.e. all days have at least a sesssion so next
                //week button must not be placed too far to the right
                mainContent.add(nextWeek, 5, 1);
                break;
        }

        
        return mainContent;
    }
    
    //This method will return the number of days that have at least one session in its day
    public int getNoDaysThatHaveSessions(int monday, int tuesday, int wednesday, int thursday, int friday){
        int daysWithSessions = 0;
        if(monday>0){
            daysWithSessions++;
        }
        if(tuesday>0){
            daysWithSessions++;
        }
        if(wednesday>0){
            daysWithSessions++;
        }
        if(thursday>0){
            daysWithSessions++;
        }
        if(friday>0){
            daysWithSessions++;
        }
        
        return daysWithSessions;
    }
    
    
    
    //This function will return the form for an assign user to add a session to a trainer
    //or trainee. Checks will also be made to see if the session they want to add is valid
    public GridPane getAddSessionForm(String trainerId){
        GridPane formLayout = new GridPane();
        formLayout.setId("add-session-form");
        formLayout.setAlignment(Pos.CENTER);
        formLayout.setHgap(10);
        formLayout.setVgap(10);
        formLayout.setPadding(new Insets(25, 25, 25, 25));    
        
        /*
        All options that can be chosen when adding a session
        */
        
        //get all course names as an option
        ArrayList<String> courseNames = new ArrayList<String>();
        for (Course course : Course.getCourseList()) {
            courseNames.add(course.getCourseName());
        }
       
        
        String[] startTimes = {"9:00", "10:00", "11:00", "12:00", "13:00", "14:00"};
        String[] weekNumbers = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
        String[] locations = {"Microsoft Teams", "Room 1", "Room 2"};
             
        
        
        
        /*Combobox for dropdown menu for each session detail
        Source: https://www.geeksforgeeks.org/javafx-combobox-with-examples/
        */
        
        
        //Course name dropdown menu
        sessionNameChoices = new ComboBox(FXCollections.observableArrayList(courseNames));
        sessionNameChoices.setPromptText("Please select a course");
        //sessionNameChoices.setId("session-name-dropdown");
        
        //Start times dropdown menu
        startTimeChoices = new ComboBox(FXCollections.observableArrayList(startTimes));
        startTimeChoices.setPromptText("Please select a start time");
        
        //End times dropdown menu
        endTimeChoices = new ComboBox(FXCollections.observableArrayList(endTimes));
        endTimeChoices.setPromptText("Please select an end time");
        
        //Week number dropdown menu
        weekNoChoices = new ComboBox(FXCollections.observableArrayList(weekNumbers));
        weekNoChoices.setPromptText("Please select a week");
        
        //Days dropdown menu
        dayChoices = new ComboBox(FXCollections.observableArrayList(days));
        dayChoices.setPromptText("Please select a day");
        
        //Locations dropdown menu
        locationChoices = new ComboBox(FXCollections.observableArrayList(locations));
        locationChoices.setPromptText("Please select a location");
        
 
        //Handle methods for each dropdown so that the dropdown lists change
        //dynamically
        sessionNameChoices.setOnAction(e -> {
            currentSessionName = ""+sessionNameChoices.getValue();
            if(startTimeChoices.getValue() != null){
                //change day options here also if you have the week and start time already
                if(weekNoChoices.getValue() != null){
                    String curStartTime = ""+startTimeChoices.getValue();
                    //get the value before colon (to be compatible with time check when getting schedule)
                    currentStartTime = Integer.parseInt(curStartTime.split(":")[0]);
                    currentWeek = ""+weekNoChoices.getValue();
                    dayChoices.setItems(getDayChoicesNow(trainerId, currentSessionName, currentStartTime, currentWeek, days));
                }
            }
        });
        startTimeChoices.setOnAction(e -> {
            //gets the current start time and modifies the end time dropdown
            String curStartTime = ""+startTimeChoices.getValue();
            currentStartTime = Integer.parseInt(curStartTime.split(":")[0]);
            endTimeChoices.setItems(getEndChoicesNow(currentStartTime, endTimes));
            if(startTimeChoices.getValue() != null && sessionNameChoices.getValue() != null && weekNoChoices.getValue() != null){
                //if all other options before day have been selected then determine the day options
                currentSessionName = ""+sessionNameChoices.getValue();
                currentWeek = ""+weekNoChoices.getValue();
                dayChoices.setItems(getDayChoicesNow(trainerId, currentSessionName, currentStartTime, currentWeek, days));
            
            }
            
        });
        endTimeChoices.setOnAction(e -> {
            if(endTimeChoices.getValue() != null){
                String curEndTime = ""+endTimeChoices.getValue();
                currentEndTime = Integer.parseInt(curEndTime.split(":")[0]);
            }
            
        
        });
        weekNoChoices.setOnAction(e -> {
            
            currentWeek = ""+weekNoChoices.getValue();
            if(startTimeChoices.getValue() != null && sessionNameChoices.getValue() != null){
                dayChoices.setItems(getDayChoicesNow(trainerId, currentSessionName, currentStartTime, currentWeek, days));
            }
            
        });

        
        
        
        //Session name
        sessionNameLabel = new Label("Session Name:");
        sessionNameLabel.setId("add-session-labels");
        formLayout.add(sessionNameLabel, 0, 1);
        formLayout.add(sessionNameChoices, 1, 1);
        
        //Start time  
        startTimeLabel = new Label("Start Time:");
        startTimeLabel.setId("add-session-labels");
        formLayout.add(startTimeLabel, 0, 2);

        formLayout.add(startTimeChoices, 1, 2);
        
        //End time 
        endTimeLabel = new Label("End Time:");
        endTimeLabel.setId("add-session-labels");
        formLayout.add(endTimeLabel, 0, 3);

        formLayout.add(endTimeChoices, 1, 3);
        
        //Week 
        weekLabel = new Label("Week Number:");
        weekLabel.setId("add-session-labels");
        formLayout.add(weekLabel, 0, 4);

        formLayout.add(weekNoChoices, 1, 4);
        
        //Day  
        dayLabel = new Label("Day:");
        dayLabel.setId("add-session-labels");
        formLayout.add(dayLabel, 0, 5);

        formLayout.add(dayChoices, 1, 5);
        
        //Location 
        locationLabel = new Label("Location (room or online):");
        locationLabel.setId("add-session-labels");
        formLayout.add(locationLabel, 0, 6);

        formLayout.add(locationChoices, 1, 6);

        //Confirm message properties
        confirmMessage = new Text();
        confirmMessage.setId("confirm-message");
        formLayout.add(confirmMessage, 1, 7);



        addSession = new Button("Add Session");
        formLayout.add(addSession, 0, 8);
        addSession.setOnAction(e -> {
            //Get the value of each dropdown choice
            //System.out.println("Session selected: "+sessionNameChoices.getValue());
            
            boolean valid = true;
            if(sessionNameChoices.getValue() == null){
                valid = false;
            }
            else if(startTimeChoices.getValue() == null){
                valid = false;
            }
            else if(endTimeChoices.getValue() == null){
                valid = false;
            }
            else if(weekNoChoices.getValue() == null){
                valid = false;
            }
            else if (dayChoices.getValue() == null){
                valid = false;
            }
            else if (locationChoices.getValue() == null){
                valid = false;
            }
            
            
            String startTime = String.valueOf(currentStartTime);
            String endTime = String.valueOf(currentEndTime);
            String day =  ""+dayChoices.getValue();
            String location = ""+locationChoices.getValue();
            
            if(valid){
                //add session to trainer selected
                Trainer trainer = Trainer.getTrainer(trainerId);
                Session session = new Session(currentSessionName, startTime, endTime, currentWeek, day, location);
                currentUser.addSession(trainer, session);

                confirmMessage.setText("You have successfully added a session to "+trainer.getUsername());
            }else{
                confirmMessage.setText("Please select from the dropdown");
            }
        
        });
        
        return formLayout;
    
    }
    
    //Function to return new list of options for end time list choices based on the 
    //current start time choices
    public ObservableList<String> getEndChoicesNow(int startTime, String[] endTimes ){
        ObservableList<String> newOptions = FXCollections.observableArrayList();
        for (int i = 0; i < endTimes.length; i++) {
            //check start time selected against the hour end time, eg: 9, 10, 11
            String endTime = endTimes[i].split(":")[0];
            int endT = Integer.parseInt(endTime);
            //end time can only be 1 or 2 hours after start time
            if(startTime < endT && (endT - startTime <=2)){
                newOptions.add(endTimes[i]);
            }
        }
        
        return newOptions;
    }
    
    //Function to check if session already exists for same day for this user
    public ObservableList<String> getDayChoicesNow(String id, String sesName, int startTime, String week, String[] days){
        ObservableList<String> newOptions = FXCollections.observableArrayList();
        for (int i = 0; i < days.length; i++) {
            newOptions.add(days[i]);
        }

        //Get the schedule for this week for this trainer/trainee user
        Trainer trainer = Trainer.getTrainer(id);
        ArrayList<Session> schedule = trainer.getSchedule(week);
        //remove duplicate sessions for each day
        Calendar.checkDuplicateSessions(schedule, "Monday");
        Calendar.checkDuplicateSessions(schedule, "Tuesday");
        Calendar.checkDuplicateSessions(schedule, "Wednesday");
        Calendar.checkDuplicateSessions(schedule, "Thursday");
        Calendar.checkDuplicateSessions(schedule, "Friday");
  
        for (Session session : schedule) {
            
            //checks if this session already exists on this day
            if(session.getName().equals(sesName)){
                String day = session.getDay();
                for (int i = 0; i < newOptions.size(); i++) {
                    if(newOptions.get(i).equals(day)){
                        newOptions.remove(newOptions.get(i));
                        break;
                    }
                }
                    
                
            }
            //if session slot is already taken
            else if(session.getStartTime().split(":")[0].equals(String.valueOf(startTime))){
                String day = session.getDay();
                for (int i = 0; i < newOptions.size(); i++) {
                    if(newOptions.get(i).equals(day)){
                        newOptions.remove(newOptions.get(i));
                        break;
                    }
                }
            }
        }
        
        return newOptions;
    }
    
    
    public void addStyleSheet(Scene scene){
        scene.getStylesheets().add(Trainer.class.getResource("UserScreen.css").toExternalForm());
        //links this scene object to css file
    }
    
}
