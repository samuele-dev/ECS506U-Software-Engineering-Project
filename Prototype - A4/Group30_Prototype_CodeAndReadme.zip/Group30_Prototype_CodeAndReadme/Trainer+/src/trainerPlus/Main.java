
package trainerPlus;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author adil
 */
public class Main extends Application{
    
    //start overrides start method in application class
    @Override
    public void start(Stage primaryStage){
        
        //create lists of each user to store their account objects during run time
        //so only need to fetch data from database once if a user logs in then out then in again.
        Trainer.createList();
        AssignStaff.createList();
        CourseStaff.createList();
        
        //create courses list and load courses from database
        Course.createCourseList();
        CourseStaff.getCourseData();
        
        new Welcome();//show login screen GUI
        
        /*
        Load all user data currently stored in database
        and create correct user objects based on that.
        
        Source: https://alvinalexander.com/java/java-mysql-select-query-example/
        */ 
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SEDB", "username", "password");
            
            String query = "SELECT * FROM USERNAME.EMPLOYEEINFO";
            
            //create java statement
            Statement statement = con.createStatement();
            
            ResultSet results = statement.executeQuery(query);
            
            //iterate through every ID in database and create corresponding objects of users
            while(results.next()){
                String ID = results.getString("ID");
                String username = results.getString("Usernames");
                String firstName = results.getString("Firstname");
                String lastName = results.getString("Lastname");
                String email = results.getString("Email");
                String phoneNo = results.getString("Phonenumber");
                switch (ID.charAt(0)){
                    case '1':
                        //IDs that start with "1" wil be Trainer objects
                        Trainer trainer = new Trainer(username, ID, firstName, lastName, email, phoneNo);
                        Trainer.addTrainerToList(trainer);
                        break;
                    case '2':
                        
                        //IDs that start with "2" will be Trainee objects
                        break;
                    case '3':
                        //IDs that start with "3" wil be AssignStaff objects
                        AssignStaff assignUser = new AssignStaff(username, ID, firstName, lastName, email, phoneNo);
                        AssignStaff.addAssignUserToList(assignUser);
                        break;
                    case '4':
                        //IDs that start with "4" wil be CourseStaff objects
                        CourseStaff courseUser = new CourseStaff(username, ID, firstName, lastName, email, phoneNo);
                        CourseStaff.addCourseStaffToList(courseUser);
                        break; 
                    default:
                        System.out.println("User found doesn't have a valid ID to be a user in this system.");
                        break;
                
                }
                
                
            }
            statement.close();
              
        } catch (Exception e) {
            System.out.println("Error in database loading");
            System.out.println("error: "+ e);
        }
                
    }
    
    //This function is used by welcome and register screens to hash the users' passwords
    public static String getHashedPassword(String password){
        /*
        Hashing algorithm
        Source: https://howtodoinjava.com/java/java-security/how-to-generate-secure-password-hash-md5-sha-pbkdf2-bcrypt-examples/

        Hashes password using Secure Hash Algorithm 256
        */

        String hashedPassword = null;
        try {
            // Create MessageDigest instance for SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            //Add password bytes to digest
            md.update(password.getBytes());
            //Get the hash's bytes 
            byte[] bytes = md.digest();//This bytes[] has bytes in decimal format
            
            //Convert this then to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            //Get complete hashed password in hex format
            hashedPassword = sb.toString();
        } 
        catch (NoSuchAlgorithmException e) 
        {
            System.out.println("Hashed failed");
            e.printStackTrace();
        }
    
        return hashedPassword;
        
    }
    
    public static void main(String[] args){
        launch(args);
    }
    
}
